package com.bookstore.online_bookstore_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookstoreBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
