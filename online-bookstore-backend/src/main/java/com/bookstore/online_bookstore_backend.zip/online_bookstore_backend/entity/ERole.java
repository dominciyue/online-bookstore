package com.bookstore.online_bookstore_backend.entity;

public enum ERole {
    ROLE_USER,
    ROLE_MODERATOR, // Optional, if you need a moderator role
    ROLE_ADMIN
} 