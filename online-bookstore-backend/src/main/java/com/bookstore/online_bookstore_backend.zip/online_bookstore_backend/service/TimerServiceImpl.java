package com.bookstore.online_bookstore_backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;
import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
@SessionScope
public class TimerServiceImpl implements TimerService {

    @Autowired
    private RedisTemplate<String, Long> redisTemplate;

    @Autowired
    private HttpSession httpSession;

    private static final String TIMER_KEY_PREFIX = "session_timer:";
    private static final long TIMER_EXPIRE_HOURS = 24; // 计时器24小时后自动过期

    @Override
    public void startTimer(Long userId) {
        String sessionId = httpSession.getId();
        String redisKey = TIMER_KEY_PREFIX + userId + ":" + sessionId;
        long startTime = System.currentTimeMillis();

        // 存储到Redis，使用用户ID和会话ID的组合作为key
        redisTemplate.opsForValue().set(redisKey, startTime, TIMER_EXPIRE_HOURS, TimeUnit.HOURS);

        System.out.println("=== TIMER DEBUG: startTimer ===");
        System.out.println("User ID: " + userId);
        System.out.println("Session ID: " + sessionId);
        System.out.println("Start time set: " + startTime);
        System.out.println("Redis key: " + redisKey);
    }

    @Override
    public long stopTimer(Long userId) {
        String sessionId = httpSession.getId();
        String redisKey = TIMER_KEY_PREFIX + userId + ":" + sessionId;

        System.out.println("=== TIMER DEBUG: stopTimer ===");
        System.out.println("User ID: " + userId);
        System.out.println("Session ID: " + sessionId);
        System.out.println("Redis key: " + redisKey);

        Long startTime = redisTemplate.opsForValue().get(redisKey);
        System.out.println("Start time from Redis: " + startTime);

        if (startTime != null) {
            long currentTime = System.currentTimeMillis();
            long elapsed = currentTime - startTime;

            // 从Redis中删除计时器
            redisTemplate.delete(redisKey);

            System.out.println("Current time: " + currentTime);
            System.out.println("Elapsed time: " + elapsed + "ms");
            System.out.println("Timer removed from Redis");

            return elapsed;
        } else {
            System.out.println("No start time found in Redis for user ID: " + userId + " and session ID: " + sessionId);
            System.out.println("Returning 0 as session duration");
        }
        return 0;
    }

    @Override
    public Map<Long, Long> getAllTimers() {
        // 在SessionScope下，我们主要关注当前会话的计时器
        String sessionId = httpSession.getId();
        Map<Long, Long> result = new HashMap<>();

        // 可以选择扫描当前会话相关的所有计时器，但这里为了简化只返回当前会话的计时器
        // 如果需要获取所有计时器，可以使用Redis的keys命令

        return result;
    }
}
